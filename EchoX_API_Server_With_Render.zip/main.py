from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict
from PIL import Image
import io

app = FastAPI()

# السماح بالوصول من أي مكان (مطلوب للتطبيق)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze/")
async def analyze(file: UploadFile = File(...)) -> Dict:
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        return {
            "diagnosis_en": "Pneumonia",
            "diagnosis_ar": "التهاب رئوي"
        }
    except Exception as e:
        return {"error": str(e)}
