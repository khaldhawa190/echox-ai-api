# EchoX AI Server (FastAPI)

## كيف تشغل الخادم محليًا:
1. تأكد إنو عندك Python 3.8 أو أعلى
2. ثبّت المتطلبات:
   pip install -r requirements.txt
3. شغّل الخادم:
   uvicorn main:app --reload

## Endpoint:
POST /analyze/

- Send: صورة CXR (PNG / JPG)
- Response:
  {
    "diagnosis_en": "Pneumonia",
    "diagnosis_ar": "التهاب رئوي"
  }
